"""Moira — AI tarot oracle Telegram bot."""

__version__ = "0.1.0"
